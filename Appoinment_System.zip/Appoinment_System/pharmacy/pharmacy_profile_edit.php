<!--
 *  Pharmacy Details Edit
 *  Author: Harilekshmi K
 *
 -->
 <head>
 
 <!--<link href="../css/style.css" rel="stylesheet" type="text/css" >-->
 <style>
     table,td,th
    {
		margin:10px auto;
		border:2px solid #663300;
        border-collapse:collapse; 
        text-align:center;
        padding:20px;
        background:rgba(0,0,0,0.5);
		color:white;
    }
  th
    {
		background-color: black;
	}
h2  {
	  text-align:center;
	  color:tomato;
	}
a   {
	 text-decoration:none;
	 color:white;
	}
 </style>
 </head>
 <?php
    require "../config.php";
	include "../header.php";
	session_start();
	
	
	if($_SESSION['namee']){
	 $_SESSION['namee'];
        $uname=$_SESSION['namee'];
	$connection = new PDO($dsn, $username, $password, $options);
	$user=$_SESSION['namee'];	
    $sel  = "Select * from pharmacy where username='$user'";
	
			$statement = $connection->prepare($sel);
            $statement->execute();
            $result = $statement->fetchAll();
			if ($result && $statement->rowCount() > 0)
		    {
			?>
       
<div class="reg">
<form name="registration" method="POST" action="pharm_action.php"  onsubmit="return validate()">
<h1> PHARMACY REGISTRATION FORM</h1><br><hr><br>
<?php	    foreach ($result as $row) { 
?>

	<label>Pharmacy Name:</label><input type="text" name="name" value="<?php echo $row['pharmacy_name'];?>" class="fld"/><br><br>
	<label>Pharmacy License Number:</label><input type="text" name="lnumber" value="<?php echo $row['pharmacy_license_no'];?>" class="fld"/><br><br>
	<label>Drugs Category:</label>
	<select name="category" value="<?php echo $row['drugs_category'];?>" class="fld">
		<option>select</option>
		<option value="homeopathy">Homeopathy</option>
		<option value="ayurveda">Ayurveda</option>
		<option value="allopathy">Allopathy</option>
		</select><br><br>
	<label>Location:</label><input type="text" name="location" value="<?php echo $row['location'];?>" class="fld"/><br><br>
	<label>Pharmacy owner Name:</label><input type="text" name="oname"  value="<?php echo $row['pharmacy_owner_name'];?>" class="fld"/><br><br>
	<label>Email:</label><input type="text" name="email" value="<?php echo $row['email'];?>" class="fld"/><br><br>
	<label>Gender:</label>
	 <?php  if($row['gender']=="female"){
	?>
	<input type="radio" name="gender" value="Male" class="rad"/>Male
	<input type="radio" name="gender" value="Female" class="rad"/>Female
	<?php
	} else { 
	?>
	<input type="radio" name="gender" value="Male" class="rad"/>Male
	<input type="radio" name="gender" value="Female" class="rad"/>Female
	<?php } ?>
	<br><br>
<h2>PERSONAL DETAILS</h2><hr><br><br>
	<label>Address</label>
	<textarea name="address" value="<?php echo $row['address'];?>" class="fld"></textarea><br><br>
	<label>Phonenumber:</label><input type="text" name="phn" value="<?php echo $row['mobile'];?>" class="fld"/><br><br>
	<label>Username:</label><input type="text" name="uname" value="<?php echo $row['username'];?>" class="fld"/><br><br>
    <p> Password must contain: 6 characters, 1 capital, 1 lowercase, 1 number</p><br>
    <label>password:</label><input type="password" name="pswd" value="<?php echo $row['pass'];?>" class="fld"/><br><br>
    <label>confirm-password:</label><input type="password" name="cpswd" value="<?php echo $row['cpass'];?>" class="fld"/><br><br>
	<input type="submit" value="Submit" name="submit" class="btn"/>
	<?php } ?>
	</form>
	<a href="pharmacy.php"><input type="submit" value="Reset" name="reset" class="btn"/></a>
    </div>
	  
        
       
    <?php } else { ?>
        <blockquote>No results found.</blockquote>
    <?php }} 
				   //session close
      require "../footer.php" ?>
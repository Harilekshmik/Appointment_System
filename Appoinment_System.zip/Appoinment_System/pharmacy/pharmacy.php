<!------
 *Pharmacy REGISTRATION
 *Features:Client side validation
 *Author:Harilekshmi K
 *-->

<?php include "../header.php";?>
<script>
  function validate()
	 {
		 var name=document.forms["registration"]["name"].value;
		 if(name=="")
		 {
			 alert("Enter a valid name");
			 document.forms["registration"]["name"].focus();
			 return false;
		 }
		 var lnumber=document.forms["registration"]["lnumber"].value;
		 if(lnumber=="")
		 {
			 alert("Enter a valid license");
			 document.forms["registration"]["lnumber"].focus();
			 return false;
		 }
		 
		
       /*var category=document.forms["registration"]["category"].value;		
		 if(category=="")
		 {
			 alert("Enter a valid category");
			 document.forms["registration"]["category"].focus();
			 return false;
		 } 
		  */
        var location=document.forms["registration"]["location"].value;
		 if(location=="")
		 {
			 alert("Enter a valid location");
			 document.forms["registration"]["location"].focus();
			 return false;
		 }	
        var oname=document.forms["registration"]["oname"].value;
		 if(oname=="")
		 {
			 alert("Enter a valid owner name");
			 document.forms["registration"]["oname"].focus();
			 return false;
		 }	
       var x=document.forms["registration"]["email"].value;  
        var atposition=x.indexOf("@");  
        var dotposition=x.lastIndexOf(".");  
        if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length)
		{  
         alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition); 
			document.forms["registration"]["email"].focus();		 
         return false;  
        } 
        var address=document.forms["registration"]["address"].value;
		if(address=="")
		{
		alert("address can't be blank");
		document.forms["registration"]["address"].focus();
		return false;
		}		
		var mobno=document.forms["registration"]["phn"].value;
		if(mobno=="")
		{
		alert("mobilenumber can't be blank");
		document.forms["registration"]["phn"].focus();
		return false;
		}
		else if(isNaN(mobno))
		 {
			 alert("mobile number should be in digits");
			 document.forms["registration"]["phn"].focus();
			 return false;
		 }
		
		
		var uname=document.forms["registration"]["uname"].value;
		if(uname=="")
		{
		alert("username can't be blank");
		document.forms["registration"]["uname"].focus();
		return false;
		}
		var pass=document.forms["registration"]["pswd"].value;
		if(pass=="")
		{
		alert("password can't be blank");
		document.forms["registration"]["pswd"].focus();
		return false;
		}
		var cpass=document.forms["registration"]["cpswd"].value;
		if(cpass=="")
		{
		alert("confirm password  can't be blank");
		document.forms["registration"]["cpswd"].focus();
		return false;
		}
		if(pass!=cpass)
		{
		alert("password mismatch");
		document.forms["registration"]["cpswd"].focus();
		return false;
		}
		 return true;
	 }
</script>
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<div class="reg">
<form name="registration" method="POST" action="pharm_action.php"  onsubmit="return validate()">
<h1> PHARMACY REGISTRATION FORM</h1><br><hr><br>
	<label>Pharmacy Name:</label><input type="text" name="name" class="fld"/><br><br>
	<label>Pharmacy License Number:</label><input type="text" name="lnumber" class="fld"/><br><br>
	<label>Drugs Category:</label>
	<select name="category"class="fld">
		<option>select</option>
		<option value="homeopathy">Homeopathy</option>
		<option value="ayurveda">Ayurveda</option>
		<option value="allopathy">Allopathy</option>
		</select><br><br>
	<label>Location:</label><input type="text" name="location" class="fld"/><br><br>
	<label>Pharmacy owner Name:</label><input type="text" name="oname" class="fld"/><br><br>
	<label>Email:</label><input type="text" name="email" class="fld"/><br><br>
	<label>Gender:</label><br><input type="radio" name="gender" value="Male" class="rad"/>Male
							  <input type="radio" name="gender" value="Female" class="rad"/>Female<br><br>
<h2>PERSONAL DETAILS</h2><hr><br><br>
	<label>Address</label>
	<textarea name="address" class="fld"></textarea><br><br>
	<label>Phonenumber:</label><input type="text" name="phn" class="fld"/><br><br>
	<label>Username:</label><input type="text" name="uname" class="fld"/><br><br>
    <p> Password must contain: 6 characters, 1 capital, 1 lowercase, 1 number</p><br>
    <label>password:</label><input type="password" name="pswd" class="fld"/><br><br>
    <label>confirm-password:</label><input type="password" name="cpswd" class="fld"/><br><br>
	<input type="submit" value="Submit" name="submit" class="btn"/>
	</form>
	<a href="pharmacy.php"><input type="submit" value="Reset" name="reset" class="btn"/></a>
	</div>
    


<!----<a href='pharm_action.php'><input type="submit" value="register" name="register" class="btn"/></a>--->
<?php include "../footer.php";?>
